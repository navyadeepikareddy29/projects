package com.jspiders.jdbc.pkg1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.Driver;

public class JdbcProgram {
	public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		Connection conn=null;
		PreparedStatement pstmt=null;
		
		
		try
		{
			Object obj=Class.forName("com.mysql.jdbc.Driver").newInstance();
			Driver d1=(Driver)obj;
		DriverManager.registerDriver(d1);
		String url="jdbc:mysql://localhost:3306/cream?user=root&password=root";
		conn=DriverManager.getConnection(url);
		String query=" insert into oreo "
				+" values(?,?,?) ";
		 pstmt=conn.prepareStatement(query);
	
		pstmt.setString(1, args[0]);
		pstmt.setString(2, args[1]);
		pstmt.setString(3, args[2]);
		int res=pstmt.executeUpdate();
		
		if(res!=0)
		{
			System.out.println( "profile updated");
		}
		
		
			
			
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		finally
		{
			try
			{
				if(conn!=null)
				{
					conn.close();
				}
				if(pstmt!=null)
				{
					pstmt.close();
				}
				
				
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		
	}

}
