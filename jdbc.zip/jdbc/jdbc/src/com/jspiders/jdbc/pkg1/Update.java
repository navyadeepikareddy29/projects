package com.jspiders.jdbc.pkg1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.mysql.jdbc.Driver;

public class Update {
	public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException  {
		Connection con=null;
		PreparedStatement pstmt=null;
		
	
		try {
			Object obj=Class.forName("com.mysql.jdbc.Driver").newInstance();
			Driver driverref=(Driver)obj;
			DriverManager.registerDriver(driverref);
			String dburl="jdbc:mysql://localhost:3306/bejm32";
		 con=DriverManager.getConnection(dburl,"root", "root");
			String query=" update studentsinfo  set fname='navya' where regNum=303";
			 pstmt=con.prepareStatement(query);
			
			int res=pstmt.executeUpdate();
			if(res!=0)
			{
				System.out.println( "profile updated");
			}
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		finally
		{
		
				try {
					if(con!=null)
					{
					con.close();
				} 
					if(pstmt!=null)
					{
						pstmt.close();
					}
				}
					catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
			
			
		}
}
